﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repo1
{
    public interface IRepository<TEntity> where TEntity : class
    {
        TEntity FindById(object id);
        void InsertGraph(TEntity entity);
        void Update(TEntity entity);
        TEntity Update(TEntity dbEntity, TEntity entity);
        void Delete(object id);
        void Delete(TEntity entity);
        void Insert(TEntity entity);
        RepositoryQuery<TEntity> Query();
        void Dispose();
        void ChangeEntityState<T>(T entity, ObjectState state) where T : class;
        TEntity SetValues(TEntity dbEntity, TEntity entity);
        void SaveChanges();
    }
}
