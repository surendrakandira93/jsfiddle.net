﻿using Data;
using Repo1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace servive
{
    public class PositionService: IPositionService
    {
        #region "Fields"
        private readonly IRepository<Position> repoOffer;
        #endregion

        #region "Constructor"
        public PositionService()
        {
            this.repoOffer = new Repository<Position>();
        }
        #endregion


        public int GetOfferById(string name)
        {
            var response= repoOffer.Query().Get().Where(x=>x.Name.ToLower().Equals(name.ToLower())).FirstOrDefault();
            return response != null ? response.Id : 1;
        }

        public bool SaveUnique(Position entity)
        {
            if (entity.Id == 0)
            {
                repoOffer.Insert(entity);
            }
            else
            {
                repoOffer.Update(entity);
            }

            return true;
        }
    }
}
