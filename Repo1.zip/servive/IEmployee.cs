﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApplication6.Core;
using Data;

namespace servive
{
  public  interface IEmployeeService
    {
        bool SaveUnique(Employee entity);
        Employee GetOfferById(int id);       
        KeyValuePair<int, List<Employee>> GetOffers(DataTableServerSide searchModel);        
        void Delete(int id);
       
       
    }
}
