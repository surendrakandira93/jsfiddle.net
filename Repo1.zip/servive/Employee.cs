﻿using Data;
using Repo1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApplication6.Core;

namespace servive
{
   public class EmployeeService: IEmployeeService
    {
        #region "Fields"
        private readonly IRepository<Employee> repoOffer;
        #endregion

        #region "Constructor"
        public EmployeeService()
        {
            this.repoOffer = new Repository<Employee>();
        }
        #endregion

        #region "Methods"
        public Employee GetOfferById(int id)
        {
            return repoOffer.FindById(id);
        }
    
        public bool SaveUnique(Employee entity)
        {
            bool isExists = !repoOffer.Query().Filter(s => s.Id != entity.Id && s.FirstName == entity.FirstName && s.LastName == entity.LastName && s.PositionId == entity.PositionId).Get().Any();
            if (isExists)
            {
                if (entity.Id == 0)
                {
                    repoOffer.Insert(entity);
                }
                else
                {
                    repoOffer.Update(entity);
                }
            }
            else
            {

            }
            return isExists;
        }


     
        public KeyValuePair<int, List<Employee>> GetOffers(DataTableServerSide searchModel)
        {
            var predicate = CustomPredicate.BuildPredicate<Employee>(searchModel);
            predicate = predicate.Or(c => c.FirstName.Contains(searchModel.search.value));
            int totalCount;
            int page = searchModel.start == 0 ? 1 : (Convert.ToInt32(Decimal.Floor(Convert.ToDecimal(searchModel.start) / searchModel.length)) + 1);
            List<Employee> results = repoOffer
                .Query()
                .Filter(predicate)
                //.CustomOrderBy(u => u.OrderBy(searchModel, new Type[] { typeof(Employee) }))
                .GetPage(page, searchModel.length, out totalCount)
                .ToList();
            KeyValuePair<int, List<Employee>> resultResponse = new KeyValuePair<int, List<Employee>>(totalCount, results);
            return resultResponse;
        }
        public void Delete(int id)
        {
            repoOffer.Delete(id);
        }

      
        #endregion

        #region "Dispose"
        public void Dispose()
        {
            if (repoOffer != null)
            {
                repoOffer.Dispose();
            }

        }
        #endregion
    }
}
